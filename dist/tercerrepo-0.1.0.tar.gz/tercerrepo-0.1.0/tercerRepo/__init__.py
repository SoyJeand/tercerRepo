def saludar(nombre):
    return "Hola " + nombre + ", este es mi primer paquete pip!"